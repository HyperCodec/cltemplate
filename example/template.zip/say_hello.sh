echo "Hello {% name %}!"
echo "{%name%} responds with {%message %}!"